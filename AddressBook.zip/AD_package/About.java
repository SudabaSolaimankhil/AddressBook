package AD_package;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class About extends JDialog {

	// Labels
	JLabel ab, im2;
	JPanel upPanel, downPanel;

	// URLs
	URL header = getClass().getResource("/images/header.jpg");
	URL tiyan = getClass().getResource("/images/tiyan.jpg");

	// Constructor
	public About() {
		// Setting of JDialog
		setSize(520, 520);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setTitle("About");
		getTitle();
		setUndecorated(true);
		setLayout(null);

		// Setting of up panel
		upPanel = new JPanel();
		upPanel.setBounds(0, 0, 520, 100);
		add(upPanel);
		upPanel.setLayout(null);

		// Setting of JLable
		ab = new JLabel(new ImageIcon(header));
		ab.setFont(new Font("", Font.ROMAN_BASELINE, 23));
		upPanel.add(ab);
		ab.setBounds(0, 0, 520, 100);
		ab.setBorder(new LineBorder(Color.blue));

		// Setting of down panel
		downPanel = new JPanel();
		downPanel.setBounds(0, 100, 520, 420);
		add(downPanel);
		downPanel.setLayout(null);

		// Setting of label
		im2 = new JLabel(new ImageIcon(tiyan));
		downPanel.add(im2);
		im2.setBounds(0, 0, 520, 420);
		im2.setBorder(new LineBorder(Color.blue));

		// Setting of exit button
		JButton exit = new JButton("بیرون شدن");
		exit.setBounds(220, 370, 80, 40);
		downPanel.setLayout(null);
		downPanel.add(exit);

		setVisible(true);

		// Action
		exit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				dispose();

			}
		});
	}
}

package AD_package;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class DeletePage extends JDialog implements ActionListener{
	
	
	// URL for images
	URL url1 = getClass().getResource("/images/deleteById.jpg");
	URL url2 = getClass().getResource("/images/deleteByPhone.jpg");
	URL url3 = getClass().getResource("/images/deleteAll.jpg");

	// Panel
	JPanel panel = new JPanel();

	// buttons of Search page
	JButton del_by_id,
			del_by_phone,
			del_All;

	// Constructor
	public  DeletePage() {
		
		// Setting of delete page
		setSize(300, 350);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
		setContentPane(panel);
		panel.setLayout(new GridLayout(3, 1));

		
		// Setting of buttons
		del_by_id = new JButton(new ImageIcon(url1));
		del_by_phone = new JButton(new ImageIcon(url2));
		del_All = new JButton(new ImageIcon(url3));
		panel.add(del_by_id);
		panel.add(del_by_phone);
		panel.add(del_All);

		// Action
		del_by_id.addActionListener(this);
		del_by_phone.addActionListener(this);
		del_All.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) { 
		JButton enter = (JButton) e.getSource();
		if (enter == del_by_id) {
			del_by_id();
		} else if (enter == del_by_phone) {
			del_by_phone();
		} else if (enter == del_All) {
			del_all();
		}
	}

	public void del_by_id() { // Method for deleting a person by id
		if (AddressBook.infoList.size() > 0) {
			String id = JOptionPane.showInputDialog("Enter the ID of the person\nyou want to delete.");
			if (AddressBook.find_Position_Existence(id) >= 0) {
				AddressBook.infoList.remove(AddressBook.find_Position_Existence(id));
				JOptionPane.showMessageDialog(null, "Delete done!");
			} else {
				JOptionPane.showMessageDialog(null, "The person dose not exist!");
			}
		} else {
				JOptionPane.showMessageDialog(null, "The list is empty!");
		}
	}
	
	public  void del_by_phone() { // Method for deleting a person by phone number
		if (AddressBook.infoList.size() > 0) {
		String phone = JOptionPane.showInputDialog("Enter the phone number");
		if (AddressBook.sea_by_phone(phone) >= 0) {
			AddressBook.infoList.remove(AddressBook.sea_by_phone(phone));
			JOptionPane.showMessageDialog(null, "Delete done!");
		} else {
			JOptionPane.showMessageDialog(null, "The person dose not exist!");
		}
		} else {
			JOptionPane.showMessageDialog(null, "The list is empty!");
	}
	}

	public  void del_all() { // Method for deleting all people
		if (AddressBook.infoList.size() > 0) {
			AddressBook.infoList.clear();
			JOptionPane.showMessageDialog(null, "Delete done!");
		} else {
			JOptionPane.showMessageDialog(null, "The list is empty!");
		}
	}
}

package AD_package;

public class Name {
	public String firstName;
	public String lastName;
	public String middleName;

	@Override
	public String toString() {
		return firstName + "#" + lastName + "#" + middleName + "#";
	}

}

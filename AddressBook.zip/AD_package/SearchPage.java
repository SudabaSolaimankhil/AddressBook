package AD_package;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class SearchPage extends JDialog implements ActionListener {
	
	// Panel
	JPanel panel = new JPanel();
	JScrollPane jsp;
	JTable jt;

	// buttons of Search page
	JButton sea_by_Name, sea_by_ID, common_sea;

	
	// URLs
	URL url1 = getClass().getResource("/images/searchByName.jpg");
	URL url2 = getClass().getResource("/images/searchById.jpg");
	URL url3 = getClass().getResource("/images/commonSearch.jpg");
	URL url4 = getClass().getResource("/images/bg1.jpg");

	
	// Constructor
	public  SearchPage() {
		
		// Setting of JDialog
		setSize(900, 380);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLayout(null);
		setResizable(false);
		setTitle("جستجو کردن");
		getTitle();
		
		// Setting of JPanel
		getContentPane().add(panel);
		panel.setLayout(new GridLayout(3,1));
		panel.setBounds(0, 0, 300, 350);
		
		// Setting of JButtons
		sea_by_Name = new JButton(new ImageIcon(url1));
		sea_by_ID = new JButton(new ImageIcon(url2)); 
		common_sea = new JButton(new ImageIcon(url3));
		panel.add(sea_by_Name);
		panel.add(sea_by_ID);
		panel.add(common_sea);
		
		// Action
		sea_by_Name.addActionListener(this);
		sea_by_ID.addActionListener(this);
		common_sea.addActionListener(this);
		
		setVisible(true);
		
	}
	
	// Actions
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton enter = (JButton) e.getSource();
		if (enter == sea_by_Name) {
			sea_by_fName();
		} else if (enter == sea_by_ID) {
			sea_by_Id();
		} else if (enter == common_sea) {
			general_sea1();
		}
	}
	
	// Method for making table and putting it in JScrolpane
	public  void putTableInScrollPane(String[][] data, String[] header) {
		
		// Setting of JScrolPane
		jsp = new JScrollPane();
		jsp.setBounds(300, 0, 600, 380);
		jsp.setVisible(true);
		getContentPane().add(jsp);

		// Setting of JTable
		jt = new JTable(data, header);
		jsp.setViewportView(jt);
		
	}

	 // Method for searching by first name
	public void sea_by_fName() {
		String[] header = {"ID","firstName","lastName","middleName","phoneNumber","homeNumber",
				"workNumber","city","disrict","streetName","streetNumber"};
		String[][] data = new String[AddressBook.infoList.size()][header.length];
		int row = 0;
			String name = JOptionPane.showInputDialog("Enter the first name of \nperson you want to search");
			for (int i = 0; i < AddressBook.infoList.size(); i++) {
				if (AddressBook.infoList.get(i).name.firstName.equals(name)) {
					String[] temp = AddressBook.infoList.get(i).toString().split("#");
					for (int column = 0; column < header.length; column++) {
						if (column < temp.length) {
							data[row][column] = temp[column];
						}

					}
					row++;
				}
			}
			putTableInScrollPane(data, header);
	}

	// Method for searching by ID
	public  void sea_by_Id() { 
		String[] header = {"ID","firstName","lastName","middleName","phoneNumber","homeNumber",
				"workNumber","city","disrict","streetName","streetNumber"};
		String[][] data = new String[AddressBook.infoList.size()][header.length];
		String id = JOptionPane.showInputDialog("Enter the id of \nperson you want to search");
		 
		if (AddressBook.find_Position_Existence(id)>= 0) {
			String [] temp = AddressBook.infoList.get(AddressBook.find_Position_Existence(id)).toString().split("#"); 
					for (int column = 0; column < header.length; column++) {
						if (column<temp.length) {
						data [0][column] = temp[column];
						}
						else 
							data[0][column] = "";
						
			}
			putTableInScrollPane(data, header);
			
		} else {
			JOptionPane.showMessageDialog(null, "The person dose not exist!");
		}
	}

	// Method for searching by every details that we remember
	public void general_sea1(){
			String[] header = {"ID","firstName","lastName","middleName","phoneNumber","homeNumber",
					"workNumber","city","disrict","streetName","streetNumber"};
			String[][] data = new String[AddressBook.infoList.size()][header.length];
			int row = 0;
				String value = JOptionPane.showInputDialog("Enter at least one property about the \nperson you want to search");
				for (int i = 0; i < AddressBook.infoList.size(); i++) {
					String s = AddressBook.infoList.get(i).toString();
					if (s.contains(value)) {
						String[] temp = s.split("#");
						for (int column = 0; column < header.length; column++) {
							if (column < temp.length) {
								data[row][column] = temp[column];
							}
						}
						row++;
					}
				}
				putTableInScrollPane(data, header);
		}
		
	// Method for searching by phone number
	public   void sea_by_phone() { 
		String[] header = {"ID","firstName","lastName","middleName","phoneNumber","homeNumber",
				"workNumber","city","disrict","streetName","streetNumber"};
		String[][] data = new String[AddressBook.infoList.size()][header.length];
		
		int row = 0;
		if (AddressBook.infoList.size() > 0) {
			String phoneNumber = JOptionPane.showInputDialog("Enter the phoneNumber of \nperson you want to search");
			for (int i = 0; i < AddressBook.infoList.size(); i++) {
				if (AddressBook.infoList.get(i).phone.phoneNumber.equals(phoneNumber)) {
					String[] temp = AddressBook.infoList.get(i).toString().split("#");
					for (int column = 0; column < header.length; column++) {
						if (column < temp.length) 
							data[row][column] = temp[column];
					}
					row++;
				}
			}
			putTableInScrollPane(data, header);
		} else 
			JOptionPane.showMessageDialog(null, "The list is empty");
	}
}



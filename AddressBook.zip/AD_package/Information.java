package AD_package;

public class Information {
	Name name;
	Phone phone;
	Address address;

	static int ID = 1;
	String id;

	public Information() {
		name = new Name();
		phone = new Phone();
		address = new Address();
		id = "P" + String.format("%03d", ID);
		ID++;
	}

	public String toString() {
		return id + "#" + name + "\n" + phone + "\n" + address;
	}
}

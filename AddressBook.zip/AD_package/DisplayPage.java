package AD_package;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class DisplayPage extends JDialog implements ActionListener {
	
	// URLs
	URL url1 = getClass().getResource("/images/displayAllinfo.jpg");
	URL url2 = getClass().getResource("/images/displayNames.jpg");
	URL url3 = getClass().getResource("/images/importantInfo.jpg");
	URL url4 = getClass().getResource("/images/bg1.jpg");
	
	
	JPanel panel = new JPanel();
	JScrollPane jsp;
	JTable jt;
	
	// buttons of dispalyPage
	JButton dis_All;
	JButton dis_as_Names;
	JButton dis_as_fname_phone_city;
	
	
	// Constructor
	public DisplayPage(){
		
		// Setting of JDialog
		setSize(900, 380);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLayout(null);
		setVisible(true);
		setResizable(false);
		setTitle("نمایش دادن");
		getSize();
		
		// Setting of JPanel
		getContentPane().add(panel);
		panel.setLayout(new GridLayout(3,1));
		panel.setBounds(0, 0, 300, 350);
		
		// Setting of JButtons
		dis_All = new JButton(new ImageIcon(url1));
		dis_as_Names = new JButton(new ImageIcon(url2)); 
		dis_as_fname_phone_city = new JButton(new ImageIcon(url3));
		panel.add(dis_All);
		panel.add(dis_as_Names);
		panel.add(dis_as_fname_phone_city);
		
		// Action
		dis_All.addActionListener(this);
		dis_as_Names.addActionListener(this);
		dis_as_fname_phone_city.addActionListener(this);
		
		jsp = new JScrollPane();
			
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton enter = (JButton) e.getSource();
		if (enter == dis_All) {
			dis_All();
		}
		else if (enter == dis_as_Names) {
			dis_as_Names();
		}
		else if (enter == dis_as_fname_phone_city) {
			dis_as_fname_phone_city();
		}
	}
	
	// Method for making a table and putting information in it
	public  void displayTableInScrollPane(String[][] data, String[] header) {
		
		// Setting of JScrooPane
		jsp.setBounds(300, 0, 600, 380);
		jsp.setVisible(true);
		getContentPane().add(jsp);

		// Setting of JTable
		jt = new JTable(data, header);
		jsp.setViewportView(jt);
	}

	// Method for displaying all information of all people
	public void dis_All() { 
		String[] header = { "ID", "firstName", "lastName", "middleName", "phoneNumber", "homeNumber", "workNumber",
				"city", "disrict", "streetName", "streetNumber" };
		String[][] data = new String[AddressBook.infoList.size()][header.length];
		
			for (int i = 0; i < AddressBook.infoList.size(); i++) {
				String[] temp = AddressBook.infoList.get(i).toString().split("#");
				for (int row = i; row < data.length; row++) {
					for (int column = 0; column < header.length; column++) {
						if (column < temp.length) {
							data[row][column] = temp[column];
						} else {
							data[row][column] = " ";
						}
					}
				}
			}
			displayTableInScrollPane(data, header);
	}

	// Method for displaying names of all people
	public void dis_as_Names() { 
		String[] header = { "firstName", "lastName", "middleName" };
		String[][] data = new String[AddressBook.infoList.size()][header.length];
		String[] temp = {};
			for (int i = 0; i < AddressBook.infoList.size(); i++) {
				temp = AddressBook.infoList.get(i).name.toString().split("#");
				for (int row = i; row < data.length; row++) {
					for (int column = 0; column < header.length; column++) {
						if (column < temp.length) {
							data[row][column] = temp[column];
						} else {
							data[row][column] = " ";
						}
					}
				}
			}
			displayTableInScrollPane(data, header);

	}

	// Method for displaying firstName , lastName & city of all people
	public void dis_as_fname_phone_city() { 
		String[] header = { "firstName", "phone number", "city" };
		String[][] data = new String[AddressBook.infoList.size()][header.length];
			for (int row = 0; row < data.length; row++) {
				data[row][0] = AddressBook.infoList.get(row).name.firstName;
				data[row][1] = AddressBook.infoList.get(row).phone.phoneNumber;
				data[row][2] = AddressBook.infoList.get(row).address.city;
			}
			displayTableInScrollPane(data, header);
	}
	
}


package AD_package;

class Phone {
	String phoneNumber;
	String homeNumber;
	String workNumber;

	@Override
	public String toString() {
		return phoneNumber + "#" + homeNumber + "#" + workNumber + "#";
	}
}

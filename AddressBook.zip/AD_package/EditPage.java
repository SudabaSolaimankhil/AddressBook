package AD_package;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class EditPage extends JDialog {

	// URL
	URL person = getClass().getResource("/images/person.jpg");

	// Panels
	JPanel leftPanel = new JPanel();
	JPanel rightPanel = new JPanel();

	// labels of addPage
	JLabel firstNameL, lastNameL, middleNameL, phoneNumberL, homeNumberL, workNumberL, cityL, districtL, streetNameL,
			streetNumberL;

	// JTextField of addPage
	JTextField firstNameT, lastNameT, middleNameT, phoneNumberT, homeNumberT, workNumberT, cityT, districtT,
			streetNameT, streetNumberT;

	// Button , index & border 
	JButton EditButton;
	int index = 0;
	LineBorder lin;

	// Constructor
	public EditPage() {

		// Setting of JDialog
		setTitle("ویرایش کردن");
		getTitle();
		setResizable(false);
		setSize(400, 324);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLayout(new GridLayout(1, 2));

		// Setting of leftPanel
		getContentPane().add(leftPanel);
		leftPanel.setLayout(null);

		ImageIcon im = new ImageIcon(person);
		JLabel jl = new JLabel();
		jl.setIcon(im);
		jl.setBounds(10, 10, 172, 121);
		leftPanel.add(jl);

		phoneNumberT = new JTextField();
		phoneNumberT.setColumns(10);
		phoneNumberT.setBounds(10, 143, 100, 25);
		leftPanel.add(phoneNumberT);

		phoneNumberL = new JLabel("شماره تماس  ");
		phoneNumberL.setBounds(120, 146, 62, 22);
		leftPanel.add(phoneNumberL);

		homeNumberT = new JTextField();
		homeNumberT.setColumns(10);
		homeNumberT.setBounds(10, 179, 100, 25);
		leftPanel.add(homeNumberT);

		homeNumberL = new JLabel("شماره خانه  ");
		homeNumberL.setBounds(120, 182, 62, 22);
		leftPanel.add(homeNumberL);

		workNumberT = new JTextField();
		workNumberT.setColumns(10);
		workNumberT.setBounds(10, 215, 100, 25);
		leftPanel.add(workNumberT);

		workNumberL = new JLabel("شماره کار  ");
		workNumberL.setBounds(120, 218, 62, 22);
		leftPanel.add(workNumberL);

		EditButton = new JButton(" انجام       ");
		EditButton.setBounds(10, 251, 172, 23);
		leftPanel.add(EditButton);

		// Setting of rightPanel
		getContentPane().add(rightPanel);
		rightPanel.setLayout(null);

		firstNameT = new JTextField();
		firstNameT.setBounds(10, 23, 100, 25);
		rightPanel.add(firstNameT);
		firstNameT.setColumns(10);

		firstNameL = new JLabel("نام        ");
		firstNameL.setBounds(120, 26, 62, 22);
		rightPanel.add(firstNameL);

		lastNameT = new JTextField();
		lastNameT.setColumns(10);
		lastNameT.setBounds(10, 59, 100, 25);
		rightPanel.add(lastNameT);

		lastNameL = new JLabel("تخلص    ");
		lastNameL.setBounds(120, 62, 62, 22);
		rightPanel.add(lastNameL);

		middleNameT = new JTextField();
		middleNameT.setColumns(10);
		middleNameT.setBounds(10, 95, 100, 25);
		rightPanel.add(middleNameT);

		middleNameL = new JLabel("شهرت     ");
		middleNameL.setBounds(120, 98, 62, 22);
		rightPanel.add(middleNameL);

		cityT = new JTextField();
		cityT.setColumns(10);
		cityT.setBounds(10, 143, 100, 25);
		rightPanel.add(cityT);

		cityL = new JLabel("شهر     ");
		cityL.setBounds(120, 146, 62, 22);
		rightPanel.add(cityL);

		districtT = new JTextField();
		districtT.setColumns(10);
		districtT.setBounds(10, 179, 100, 25);
		rightPanel.add(districtT);

		districtL = new JLabel("ناحیه      ");
		districtL.setBounds(120, 182, 62, 22);
		rightPanel.add(districtL);

		streetNameT = new JTextField();
		streetNameT.setColumns(10);
		streetNameT.setBounds(10, 215, 100, 25);
		rightPanel.add(streetNameT);

		streetNameL = new JLabel("نام خیابان ");
		streetNameL.setBounds(120, 218, 62, 22);
		rightPanel.add(streetNameL);

		streetNumberT = new JTextField();
		streetNumberT.setColumns(10);
		streetNumberT.setBounds(10, 251, 100, 25);
		rightPanel.add(streetNumberT);

		streetNumberL = new JLabel("نمبر خیابان ");
		streetNumberL.setBounds(120, 254, 62, 22);
		rightPanel.add(streetNumberL);

		String id = JOptionPane.showInputDialog("Enter the ID of the person you want to edit"
				+ "\nNote:When you edit the properties of a person \n" + "he\\she takes a new ID.", "Ex: P001");
		if (AddressBook.find_Position_Existence(id) >= 0) {
			index = AddressBook.find_Position_Existence(id);
			firstNameT.setText(AddressBook.infoList.get(index).name.firstName);
			lastNameT.setText(AddressBook.infoList.get(index).name.lastName);
			middleNameT.setText(AddressBook.infoList.get(index).name.middleName);
			phoneNumberT.setText(AddressBook.infoList.get(index).phone.phoneNumber);
			homeNumberT.setText(AddressBook.infoList.get(index).phone.homeNumber);
			workNumberT.setText(AddressBook.infoList.get(index).phone.workNumber);
			cityT.setText(AddressBook.infoList.get(index).address.city);
			districtT.setText(AddressBook.infoList.get(index).address.district);
			streetNameT.setText(AddressBook.infoList.get(index).address.streetName);
			streetNumberT.setText(AddressBook.infoList.get(index).address.streetNumber);
			setVisible(true);
		} else {
			JOptionPane.showMessageDialog(null, "The person does not exist!");
		}

		EditButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// Validation
				if (firstNameT.getText().equals("")) {
					firstNameL.setBorder(lin = new LineBorder(Color.RED, 2));
					firstNameL.setForeground(Color.RED);
					firstNameT.setToolTipText("You have to enter the first name!");
					firstNameT.setBackground(new Color(255, 185, 185));
				} else if (cityT.getText().equals("")) {
					cityL.setBorder(lin = new LineBorder(Color.RED, 2));
					cityL.setForeground(Color.RED);
					cityT.setToolTipText("You have to enter the city!");
					cityT.setBackground(new Color(255, 185, 185));
				} else if (phoneNumberT.getText().equals("")) {
					phoneNumberL.setBorder(lin = new LineBorder(Color.RED, 2));
					phoneNumberL.setForeground(Color.RED);
					phoneNumberT.setToolTipText("You have to enter the phone number!");
					phoneNumberT.setBackground(new Color(255, 185, 185));
				}

				else {
					AddressBook.edit(firstNameT.getText(), lastNameT.getText(), middleNameT.getText(),
							phoneNumberT.getText(), homeNumberT.getText(), workNumberT.getText(), cityT.getText(),
							districtT.getText(), streetNameT.getText(), streetNumberT.getText(), index);
					dispose();
				}

			}
		});
	}

}

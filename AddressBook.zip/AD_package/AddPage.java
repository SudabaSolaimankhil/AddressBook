package AD_package;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class AddPage extends JDialog {
	
	// URL for getting image
	URL person = getClass().getResource("/images/person.jpg");

	// Panels
	JPanel leftPanel = new JPanel();
	JPanel rightPanel = new JPanel();

	// labels of addPage
	JLabel firstNameL, lastNameL, middleNameL, phoneNumberL, homeNumberL, workNumberL, cityL, districtL, streetNameL,
			streetNumberL;

	// JTextField of addPage
	JTextField firstNameT, lastNameT, middleNameT, phoneNumberT, homeNumberT, workNumberT, cityT, districtT,
			streetNameT, streetNumberT;
	
	// Button
	JButton addBtn;
	
	// Border
	LineBorder lin;

	// Constructor
	public AddPage() {

		// Setting of JDialog
		setTitle("اضافه کردن");
		getTitle();
		setResizable(false);
		setSize(400, 324);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
		setLayout(new GridLayout(1, 2));

		// Setting of leftPanel
		getContentPane().add(leftPanel);
		leftPanel.setLayout(null);
		
		// Setting of JLable for putting an image in add page
		JLabel jl = new JLabel(new ImageIcon(person));
		jl.setBounds(10, 10, 172, 121);
		leftPanel.add(jl);
		
		
		// Setting of rightPanel
		getContentPane().add(rightPanel);
		rightPanel.setLayout(null);
		
		// Setting of first name textfield
		firstNameT = new JTextField();
		firstNameT.setBounds(10, 23, 100, 25);
		rightPanel.add(firstNameT);
		firstNameT.setColumns(10);

		// Setting of first name lable
		firstNameL = new JLabel("نام        ");
		firstNameL.setBounds(120, 26, 62, 22);
		rightPanel.add(firstNameL);
		firstNameL.setBorder(lin = new LineBorder(Color.GRAY, 2));

		// Setting of last name textfield
		lastNameT = new JTextField();
		lastNameT.setColumns(10);
		lastNameT.setBounds(10, 59, 100, 25);
		rightPanel.add(lastNameT);

		// Setting of last name label
		lastNameL = new JLabel("تخلص     ");
		lastNameL.setBounds(120, 62, 62, 22);
		rightPanel.add(lastNameL);
		lastNameL.setBorder(lin = new LineBorder(Color.GRAY, 2));
		
		// Setting of middle name textfield
		middleNameT = new JTextField();
		middleNameT.setColumns(10);
		middleNameT.setBounds(10, 95, 100, 25);
		rightPanel.add(middleNameT);

		// Setting of middle name label
		middleNameL = new JLabel("شهرت      ");
		middleNameL.setBounds(120, 98, 62, 22);
		rightPanel.add(middleNameL);
		middleNameL.setBorder(lin = new LineBorder(Color.GRAY, 2));
		
		// Setting of city text field
		cityT = new JTextField();
		cityT.setColumns(10);
		cityT.setBounds(10, 143, 100, 25);
		rightPanel.add(cityT);

		// Setting of city label
		cityL = new JLabel("شهر       ");
		cityL.setBounds(120, 146, 62, 22);
		rightPanel.add(cityL);
		cityL.setBorder(lin = new LineBorder(Color.GRAY, 2));

		// Setting of district textfield
		districtT = new JTextField();
		districtT.setColumns(10);
		districtT.setBounds(10, 179, 100, 25);
		rightPanel.add(districtT);

		// Setting of district lable
		districtL = new JLabel("ناحیه       ");
		districtL.setBounds(120, 182, 62, 22);
		rightPanel.add(districtL);
		districtL.setBorder(lin = new LineBorder(Color.GRAY, 2));

		// Setting of street name textfield
		streetNameT = new JTextField();
		streetNameT.setColumns(10);
		streetNameT.setBounds(10, 215, 100, 25);
		rightPanel.add(streetNameT);

		// Setting of street name label
		streetNameL = new JLabel("نام خیابان  ");
		streetNameL.setBounds(120, 218, 62, 22);
		rightPanel.add(streetNameL);
		streetNameL.setBorder(lin = new LineBorder(Color.GRAY, 2));

		// Setting of street number textfield
		streetNumberT = new JTextField();
		streetNumberT.setColumns(10);
		streetNumberT.setBounds(10, 251, 100, 25);
		rightPanel.add(streetNumberT);

		// Setting of street number label
		streetNumberL = new JLabel("نمبر خیابان  ");
		streetNumberL.setBounds(120, 254, 62, 22);
		rightPanel.add(streetNumberL);
		streetNumberL.setBorder(lin = new LineBorder(Color.GRAY, 2));
		
		// Setting of phone number textfield
		phoneNumberT = new JTextField();
		phoneNumberT.setColumns(10);
		phoneNumberT.setBounds(10, 143, 100, 25);
		leftPanel.add(phoneNumberT);

		// Setting of phone number label
		phoneNumberL = new JLabel("شماره تماس ");
		phoneNumberL.setBounds(120, 146, 62, 22);
		leftPanel.add(phoneNumberL);
		phoneNumberL.setBorder(lin = new LineBorder(Color.GRAY, 2));

		// Setting of home number textfield
		homeNumberT = new JTextField();
		homeNumberT.setColumns(10);
		homeNumberT.setBounds(10, 179, 100, 25);
		leftPanel.add(homeNumberT);

		// Setting of home number lable
		homeNumberL = new JLabel("شماره خانه ");
		homeNumberL.setBounds(120, 182, 62, 22);
		leftPanel.add(homeNumberL);
		homeNumberL.setBorder(lin = new LineBorder(Color.GRAY, 2));

		// Setting of work number textfield
		workNumberT = new JTextField();
		workNumberT.setColumns(10);
		workNumberT.setBounds(10, 215, 100, 25);
		leftPanel.add(workNumberT);

		// Setting of work number label
		workNumberL = new JLabel("شماره کار  ");
		workNumberL.setBounds(120, 218, 62, 22);
		leftPanel.add(workNumberL);
		workNumberL.setBorder(lin = new LineBorder(Color.GRAY, 2));

		// Setting of add button
		addBtn = new JButton("اضافه کردن");
		addBtn.setBounds(10, 251, 172, 23);
		leftPanel.add(addBtn);
		

		addBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Validation
				if (firstNameT.getText().equals("")) {
					firstNameL.setBorder(lin = new LineBorder(Color.RED, 2));
					firstNameL.setForeground(Color.RED);
					firstNameT.setToolTipText("You have to enter the first name!");
					firstNameT.setBackground(new Color(255, 185, 185));
				} else if (cityT.getText().equals("")) {
					cityL.setBorder(lin = new LineBorder(Color.RED, 2));
					cityL.setForeground(Color.RED);
					cityT.setToolTipText("You have to enter the city!");
					cityT.setBackground(new Color(255, 185, 185));
				} else if (phoneNumberT.getText().equals("")) {
					phoneNumberL.setBorder(lin = new LineBorder(Color.RED, 2));
					phoneNumberL.setForeground(Color.RED);
					phoneNumberT.setToolTipText("You have to enter the phone number!");
					phoneNumberT.setBackground(new Color(255, 185, 185));
				}

				else {
					AddressBook.add(firstNameT.getText(), lastNameT.getText(), middleNameT.getText(),
							phoneNumberT.getText(), homeNumberT.getText(), workNumberT.getText(), cityT.getText(),
							districtT.getText(), streetNameT.getText(), streetNumberT.getText());
					dispose();
				}

			}
		});

	}

}

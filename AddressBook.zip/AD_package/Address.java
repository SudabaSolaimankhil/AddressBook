package AD_package;

public class Address {
	String city;
	String district;
	String streetName;
	String streetNumber;

	@Override
	public String toString() {
		return city + "#" + district + "#" + streetName + "#" + streetNumber;
	}

}

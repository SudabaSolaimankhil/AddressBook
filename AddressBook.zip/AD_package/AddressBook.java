package AD_package;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class AddressBook extends JFrame implements ActionListener {
	
	// Making scanner object
	public static Scanner s = new Scanner(System.in);
	
	// Making a list for storing information
	public static ArrayList<Information> infoList = new ArrayList<Information>();

	// Making JFrame & JPanel objects
	JFrame mainPage = new JFrame("آدرس بوک");
	JPanel mainPanel = new JPanel();

	// buttons of mainPage
	JButton display_btn, add_btn, search_btn, delete_btn, edit_btn, about_btn;

	// URLs
	URL url1 = getClass().getResource("/images/display.jpg");
	URL url2 = getClass().getResource("/images/add.jpg");
	URL url3 = getClass().getResource("/images/search.jpg");
	URL url4 = getClass().getResource("/images/delete.jpg");
	URL url5 = getClass().getResource("/images/edit.jpg");
	URL url6 = getClass().getResource("/images/about.jpg");

	 // The Constructor
	public AddressBook() {
		// Setting of JFrame
		setTitle("آدرس بوک");
		getTitle();
		setResizable(false);
		setSize(300, 500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Adding JPanel to the JFrame
		setContentPane(mainPanel); 
		mainPanel.setLayout(new GridLayout(6, 1)); 
													

		// Creating Buttons
		display_btn = new JButton(new ImageIcon(url1));
		add_btn = new JButton(new ImageIcon(url2));
		search_btn = new JButton(new ImageIcon(url3));
		delete_btn = new JButton(new ImageIcon(url4));
		edit_btn = new JButton(new ImageIcon(url5));
		about_btn = new JButton(new ImageIcon(url6));

		// Adding buttons to the JPanel
		mainPanel.add(display_btn);
		mainPanel.add(add_btn);
		mainPanel.add(search_btn);
		mainPanel.add(delete_btn);
		mainPanel.add(edit_btn);
		mainPanel.add(about_btn);

		// Font
		display_btn.setFont(new Font("", Font.BOLD, 25));
		add_btn.setFont(new Font("", Font.BOLD, 25));
		search_btn.setFont(new Font("", Font.BOLD, 25));
		delete_btn.setFont(new Font("", Font.BOLD, 25));
		edit_btn.setFont(new Font("", Font.BOLD, 25));
		about_btn.setFont(new Font("", Font.BOLD, 25));

		// Action
		display_btn.addActionListener(this);
		add_btn.addActionListener(this);
		search_btn.addActionListener(this);
		delete_btn.addActionListener(this);
		edit_btn.addActionListener(this);
		about_btn.addActionListener(this);

		setVisible(true);
	}

	// Actions
	public void actionPerformed(ActionEvent e) { 
		JButton enter = (JButton) e.getSource();
		if (enter == display_btn) {
			if (infoList.size() > 0) {
				DisplayPage dp = new DisplayPage();
			} else
				JOptionPane.showMessageDialog(null, "The list is empty!");
		} else if (enter == add_btn) {
			AddPage ap = new AddPage();
		} else if (enter == search_btn) {
			if (infoList.size() > 0) {
				SearchPage sp = new SearchPage();
			} else
				JOptionPane.showMessageDialog(null, "The list is empty!");
		} else if (enter == delete_btn) {
			if (infoList.size() > 0) {
				DeletePage dp = new DeletePage();
			} else
				JOptionPane.showMessageDialog(null, "The list is empty!");
		} else if (enter == edit_btn) {
			if (infoList.size() > 0) {
				EditPage ep = new EditPage();
			} else
				JOptionPane.showMessageDialog(null, "The list is empty!");
		} else if (enter == about_btn) {
			About ab = new About();
		}

	}

	// Add method for adding information to the list
	public static void add(String firstName, String lastName, String middleName, String phoneNumber, String homeNumber,
			String workNumber, String city, String disrict, String streetName, String streetNumber) {

		Information info = new Information();
		info.name.firstName = firstName;
		info.name.lastName = lastName;
		info.name.middleName = middleName;
		info.phone.phoneNumber = phoneNumber;
		info.phone.homeNumber = homeNumber;
		info.phone.workNumber = workNumber;
		info.address.city = city;
		info.address.district = disrict;
		info.address.streetName = streetName;
		info.address.streetNumber = streetNumber;
		infoList.add(info);

	}

	// Edit method for editing people details
	public static void edit(String firstName, String lastName, String middleName, String phoneNumber, String homeNumber,
			String workNumber, String city, String disrict, String streetName, String streetNumber, int index) {

		Information info = new Information();
		info.name.firstName = firstName;
		info.name.lastName = lastName;
		info.name.middleName = middleName;
		info.phone.phoneNumber = phoneNumber;
		info.phone.homeNumber = homeNumber;
		info.phone.workNumber = workNumber;
		info.address.city = city;
		info.address.district = disrict;
		info.address.streetName = streetName;
		info.address.streetNumber = streetNumber;
		infoList.set(index, info);
	}

	/*
	 * Method for finding the position of one person or
	 * to find the existence of one person
	 */
	public static int find_Position_Existence(String id) {
		int pos = -1;
		for (int i = 0; i < infoList.size(); i++) {
			if (infoList.get(i).id.equals(id)) {
				pos = i;
				return pos;
			}
		}
		return pos;
	}
	
	// Method  searching by phone number
	public static int sea_by_phone(String phone) {
		int pos = -1;
		for (int i = 0; i < infoList.size(); i++) {
			if (infoList.get(i).phone.phoneNumber.equals(phone)) {
				pos = i;
				break;
			}
		}
		return pos;

	}

}
